from ast import Delete
from asyncio.windows_events import NULL
from cgitb import text
from contextlib import redirect_stderr
from django.shortcuts import render,HttpResponse
from app01.models import UserInfo
#encoding:utf-8

# Create your views here.
def begin(request):
   if request.method =="GET":
    return render(request,"begin.html")

def login (request):
    if request.method =="GET":
        return render(request,"login.html")
    username = request.POST.get("user")
    password = request.POST.get("pws")
    if username =="root" and password == "123":
        return HttpResponse("login success")
    return render(request,"login.html",{"error":"password or username wrong"} )
   

def register(request):
   if request.method =="GET":
        return render(request,"register.html")
   else:
    username = request.POST.get("user")
    password = request.POST.get("pws")
    nickname = request.POST.get("nick")
    if len(username) <= 10 and len(username) >=2 and len(password) <= 20 and len(password) >=2 and  len(nickname) <= 20 and len(nickname) >=1 :
      account_list = UserInfo.objects.all()
      for item in account_list:
       if(item.name==username):
        return HttpResponse("username has been used")
      else:
        UserInfo.objects.create(name=username,password=password,nickname=nickname)
        return HttpResponse("register success")
    s1= "username is ok"
    s2= "password is ok"
    s3= "nickname is ok"
    if(len(username) >= 10 or len(username) <=2): 
     s1="username is false"

    if(len(password) >= 10 or len(password) <=2): 
     s2="password is false"

    if(len(nickname) >= 20 or len(nickname) <=1): 
     s3="nickname is false"
    return HttpResponse("register fail: "+s1+", "+s2+", "+s3)
 
    