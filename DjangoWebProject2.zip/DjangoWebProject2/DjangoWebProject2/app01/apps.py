from django.apps import AppConfig


class app01Config(AppConfig):
    name = 'app01'
