"""
Package for DjangoWebProject2.
"""
